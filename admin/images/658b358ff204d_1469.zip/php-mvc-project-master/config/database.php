<?php

return [
    'default' => env('DB_DRIVER', 'sqlite')
];
